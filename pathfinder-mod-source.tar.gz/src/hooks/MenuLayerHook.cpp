#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/binding/CCMenuItemSpriteExtra.hpp>

#include "../ui/PathfinderPopup.hpp"

using namespace geode::prelude;

class $modify(MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;

        auto sprite = CCSprite::create("pathfinder-btn.png"_spr);
        if (!sprite) return true;
        sprite->setScale(0.85f);

        auto btn = CCMenuItemSpriteExtra::create(
            sprite, this,
            menu_selector(MenuLayer::onMoreGames) // placeholder; replaced below
        );
        btn->setID("pathfinder-button"_spr);

        // Re-bind to our handler.
        btn->m_pfnSelector = menu_selector(MenuLayer::onPathfinderHub);

        auto menu = this->getChildByID("bottom-menu");
        if (menu) {
            menu->addChild(btn);
            menu->updateLayout();
        } else {
            auto fallback = CCMenu::create();
            fallback->setPosition({ CCDirector::sharedDirector()->getWinSize().width - 40.0f, 40.0f });
            fallback->addChild(btn);
            this->addChild(fallback);
        }
        return true;
    }

    void onPathfinderHub(CCObject*) {
        if (auto popup = pathfinder::PathfinderPopup::create()) {
            popup->show();
        }
    }
};
