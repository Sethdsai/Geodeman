#include "PathfinderPopup.hpp"
#include "../ai/LevelGenerator.hpp"

#include <Geode/Geode.hpp>
#include <Geode/binding/GameLevelManager.hpp>
#include <Geode/binding/GJGameLevel.hpp>
#include <Geode/binding/PlayLayer.hpp>
#include <Geode/utils/cocos.hpp>

#include <random>

using namespace geode::prelude;

namespace pathfinder {

bool PathfinderPopup::setup() {
    this->setTitle("Pathfinder");

    auto winSize = m_mainLayer->getContentSize();

    auto banner = CCSprite::create("pathfinder-banner.png"_spr);
    if (banner) {
        banner->setScale(0.55f);
        banner->setPosition({ winSize.width / 2.0f, winSize.height - 70.0f });
        m_mainLayer->addChild(banner);
    }

    auto menu = CCMenu::create();
    menu->setPosition({ winSize.width / 2.0f, winSize.height / 2.0f - 30.0f });

    auto botSpr = ButtonSprite::create("Toggle Bot", "bigFont.fnt", "GJ_button_01.png");
    botSpr->setScale(0.7f);
    auto botBtn = CCMenuItemSpriteExtra::create(
        botSpr, this, menu_selector(PathfinderPopup::onToggleBot));
    botBtn->setPositionY(40.0f);
    menu->addChild(botBtn);

    auto genSpr = ButtonSprite::create("Generate Level", "bigFont.fnt", "GJ_button_02.png");
    genSpr->setScale(0.7f);
    auto genBtn = CCMenuItemSpriteExtra::create(
        genSpr, this, menu_selector(PathfinderPopup::onGenerateLevel));
    menu->addChild(genBtn);

    auto setSpr = ButtonSprite::create("Settings", "bigFont.fnt", "GJ_button_04.png");
    setSpr->setScale(0.7f);
    auto setBtn = CCMenuItemSpriteExtra::create(
        setSpr, this, menu_selector(PathfinderPopup::onOpenSettings));
    setBtn->setPositionY(-40.0f);
    menu->addChild(setBtn);

    m_mainLayer->addChild(menu);
    return true;
}

void PathfinderPopup::onToggleBot(CCObject*) {
    auto mod = Mod::get();
    bool current = mod->getSettingValue<bool>("bot-enabled");
    mod->setSettingValue<bool>("bot-enabled", !current);
    Notification::create(!current ? "Bot enabled" : "Bot disabled",
                         NotificationIcon::Info)->show();
}

void PathfinderPopup::onGenerateLevel(CCObject*) {
    auto mod = Mod::get();
    int difficulty = mod->getSettingValue<int64_t>("generator-difficulty");
    std::string mix = mod->getSettingValue<std::string>("generator-mode-mix");

    std::vector<GameMode> allowed;
    if (mix == "all") {
        for (int i = 0; i < static_cast<int>(GameMode::COUNT); ++i) {
            allowed.push_back(static_cast<GameMode>(i));
        }
    } else if (mix == "cube")   allowed = { GameMode::Cube };
    else if (mix == "ship")     allowed = { GameMode::Ship };
    else if (mix == "ball")     allowed = { GameMode::Ball };
    else if (mix == "ufo")      allowed = { GameMode::Ufo };
    else if (mix == "wave")     allowed = { GameMode::Wave };
    else if (mix == "robot")    allowed = { GameMode::Robot };
    else if (mix == "spider")   allowed = { GameMode::Spider };
    else if (mix == "swing")    allowed = { GameMode::Swing };

    std::random_device rd;
    auto level = LevelGenerator::generate(difficulty, allowed, rd());

    Notification::create(
        fmt::format("Generated '{}' ({} objects)", level.title, level.objects.size()),
        NotificationIcon::Success)->show();

    // In the full implementation, the GeneratedLevel is serialized to GD's
    // level string format and handed to PlayLayer::create. That conversion
    // is a few hundred lines of object-property packing; the scaffold leaves
    // a hook here so it can be filled in incrementally.
    log::info("Level ready to be packed and launched.");
}

void PathfinderPopup::onOpenSettings(CCObject*) {
    geode::openSettingsPopup(Mod::get());
}

PathfinderPopup* PathfinderPopup::create() {
    auto ret = new PathfinderPopup();
    if (ret->initAnchored(360.0f, 280.0f)) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

} // namespace pathfinder
